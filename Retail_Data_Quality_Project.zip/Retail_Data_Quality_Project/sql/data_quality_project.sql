-- ==========================================================
-- Data Quality Analysis Project
-- Database: data_quality.db
-- Author: Mikolaj Burzykowski
-- Date: 05-12-2025
-- This script contains SQL queries used to assess quality issues
-- in property address datasets imported from CSV files.
-- ==========================================================


-- ==========================================================
-- SECTION 1: Basic dataset metrics
-- ==========================================================

-- Counts total number of records in each source table
SELECT 'CleanedData' AS TableName, COUNT(*) AS TotalRecords
FROM CleanedData;

SELECT 'Checks' AS TableName, COUNT(*) AS TotalRecords
FROM Checks;


-- ==========================================================
-- SECTION 2: Global data quality status
-- ==========================================================

-- Returns total number of valid vs invalid entries
SELECT AnyError, COUNT(*) AS CountRows
FROM CleanedData
GROUP BY AnyError;

-- Calculates error percentage across the dataset
SELECT
    SUM(CASE WHEN AnyError = 'ERROR' THEN 1 ELSE 0 END) AS ErrorCount,
    COUNT(*) AS TotalRows,
    ROUND(100.0 * SUM(CASE WHEN AnyError = 'ERROR' THEN 1 ELSE 0 END) / COUNT(*), 2) AS ErrorRatePercent
FROM CleanedData;


-- ==========================================================
-- SECTION 3: Breakdown of errors
-- ==========================================================

-- Shows which error types are most frequent
SELECT ErrorType, COUNT(*) AS Total
FROM Checks
GROUP BY ErrorType
ORDER BY Total DESC;

-- Identifies countries where issues occur most often
SELECT Country, COUNT(*) AS ErrorCount
FROM CleanedData
WHERE AnyError = 'ERROR'
GROUP BY Country
ORDER BY ErrorCount DESC;

-- Identifies systems contributing most incorrect data
SELECT SourceSystem, COUNT(*) AS ErrorCount
FROM CleanedData
WHERE AnyError = 'ERROR'
GROUP BY SourceSystem
ORDER BY ErrorCount DESC;


-- Calculates monthly trend of error occurrence
SELECT SUBSTR(UpdatedDate, 4, 7) AS MonthYear, COUNT(*) AS ErrorCount
FROM CleanedData
WHERE AnyError = 'ERROR'
GROUP BY MonthYear
ORDER BY MonthYear;


-- ==========================================================
-- SECTION 4: Final report table
-- ==========================================================

DROP TABLE IF EXISTS ErrorReport;

-- Creates a final consolidated dataset containing only incorrect rows
CREATE TABLE ErrorReport AS
SELECT
    c.PropertyID,
    c.Country,
    c.SourceSystem,
    ck.ErrorType,
    c.UpdatedDate
FROM CleanedData c
JOIN Checks ck ON c.PropertyID = ck.PropertyID
WHERE c.AnyError = 'ERROR';


-- ==========================================================
-- SECTION 5: Data consistency checks between tables
-- ==========================================================

DROP TABLE IF EXISTS MissingInChecks;
CREATE TABLE MissingInChecks AS
SELECT c.*
FROM CleanedData c
LEFT JOIN Checks ck ON c.PropertyID = ck.PropertyID
WHERE ck.PropertyID IS NULL;

DROP TABLE IF EXISTS MissingInCleanedData;
CREATE TABLE MissingInCleanedData AS
SELECT ck.*
FROM Checks ck
LEFT JOIN CleanedData c ON c.PropertyID = ck.PropertyID
WHERE c.PropertyID IS NULL;